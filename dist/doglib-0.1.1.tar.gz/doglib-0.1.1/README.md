# Doglib

A simple package to manage dogs. Its aim is to demonstrate the use of packages in Python.

Example use:
    
```python
from doglib import Dog

buddy = Dog("Buddy", 7, "small")
buddy.bark()
buddy.feed()
```